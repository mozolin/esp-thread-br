jsmin-php
=========

This project is unmaintained. I stopped using it years ago. You shouldn't use
it. You shouldn't use any version of JSMin. There are much better tools
available now.

Here are some of them:

- [Uglify](https://github.com/mishoo/UglifyJS2)
- [Google Closure Compiler](https://developers.google.com/closure/compiler/)
- [JShrink](https://github.com/tedivm/JShrink)