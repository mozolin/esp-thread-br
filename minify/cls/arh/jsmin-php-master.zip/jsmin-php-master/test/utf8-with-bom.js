﻿var foo = function() {
    var bar = 2
    !bar
    ~bar
    return bar
};